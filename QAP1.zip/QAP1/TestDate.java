package QAP1;

public class TestDate {
    public static void main(String[] args) {
        // Create a Date object
        Date date = new Date(8, 5, 2024);

        // Print the date using toString() method
        System.out.println("Date: " + date.toString());
    }
}
